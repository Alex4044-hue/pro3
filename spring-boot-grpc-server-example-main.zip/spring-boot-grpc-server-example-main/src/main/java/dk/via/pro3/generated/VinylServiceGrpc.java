package dk.via.pro3.generated;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class VinylServiceGrpc {

  private VinylServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "dk.via.pro3.generated.VinylService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<dk.via.pro3.generated.AddVinylRequest,
      dk.via.pro3.generated.VinylResponse> getAddVinylMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddVinyl",
      requestType = dk.via.pro3.generated.AddVinylRequest.class,
      responseType = dk.via.pro3.generated.VinylResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<dk.via.pro3.generated.AddVinylRequest,
      dk.via.pro3.generated.VinylResponse> getAddVinylMethod() {
    io.grpc.MethodDescriptor<dk.via.pro3.generated.AddVinylRequest, dk.via.pro3.generated.VinylResponse> getAddVinylMethod;
    if ((getAddVinylMethod = VinylServiceGrpc.getAddVinylMethod) == null) {
      synchronized (VinylServiceGrpc.class) {
        if ((getAddVinylMethod = VinylServiceGrpc.getAddVinylMethod) == null) {
          VinylServiceGrpc.getAddVinylMethod = getAddVinylMethod =
              io.grpc.MethodDescriptor.<dk.via.pro3.generated.AddVinylRequest, dk.via.pro3.generated.VinylResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddVinyl"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  dk.via.pro3.generated.AddVinylRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  dk.via.pro3.generated.VinylResponse.getDefaultInstance()))
              .setSchemaDescriptor(new VinylServiceMethodDescriptorSupplier("AddVinyl"))
              .build();
        }
      }
    }
    return getAddVinylMethod;
  }

  private static volatile io.grpc.MethodDescriptor<dk.via.pro3.generated.GetVinylRequest,
      dk.via.pro3.generated.VinylResponse> getGetVinylMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetVinyl",
      requestType = dk.via.pro3.generated.GetVinylRequest.class,
      responseType = dk.via.pro3.generated.VinylResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<dk.via.pro3.generated.GetVinylRequest,
      dk.via.pro3.generated.VinylResponse> getGetVinylMethod() {
    io.grpc.MethodDescriptor<dk.via.pro3.generated.GetVinylRequest, dk.via.pro3.generated.VinylResponse> getGetVinylMethod;
    if ((getGetVinylMethod = VinylServiceGrpc.getGetVinylMethod) == null) {
      synchronized (VinylServiceGrpc.class) {
        if ((getGetVinylMethod = VinylServiceGrpc.getGetVinylMethod) == null) {
          VinylServiceGrpc.getGetVinylMethod = getGetVinylMethod =
              io.grpc.MethodDescriptor.<dk.via.pro3.generated.GetVinylRequest, dk.via.pro3.generated.VinylResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetVinyl"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  dk.via.pro3.generated.GetVinylRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  dk.via.pro3.generated.VinylResponse.getDefaultInstance()))
              .setSchemaDescriptor(new VinylServiceMethodDescriptorSupplier("GetVinyl"))
              .build();
        }
      }
    }
    return getGetVinylMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static VinylServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<VinylServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<VinylServiceStub>() {
        @java.lang.Override
        public VinylServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new VinylServiceStub(channel, callOptions);
        }
      };
    return VinylServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static VinylServiceBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<VinylServiceBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<VinylServiceBlockingV2Stub>() {
        @java.lang.Override
        public VinylServiceBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new VinylServiceBlockingV2Stub(channel, callOptions);
        }
      };
    return VinylServiceBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static VinylServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<VinylServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<VinylServiceBlockingStub>() {
        @java.lang.Override
        public VinylServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new VinylServiceBlockingStub(channel, callOptions);
        }
      };
    return VinylServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static VinylServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<VinylServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<VinylServiceFutureStub>() {
        @java.lang.Override
        public VinylServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new VinylServiceFutureStub(channel, callOptions);
        }
      };
    return VinylServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void addVinyl(dk.via.pro3.generated.AddVinylRequest request,
        io.grpc.stub.StreamObserver<dk.via.pro3.generated.VinylResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddVinylMethod(), responseObserver);
    }

    /**
     */
    default void getVinyl(dk.via.pro3.generated.GetVinylRequest request,
        io.grpc.stub.StreamObserver<dk.via.pro3.generated.VinylResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetVinylMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service VinylService.
   */
  public static abstract class VinylServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return VinylServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service VinylService.
   */
  public static final class VinylServiceStub
      extends io.grpc.stub.AbstractAsyncStub<VinylServiceStub> {
    private VinylServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected VinylServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new VinylServiceStub(channel, callOptions);
    }

    /**
     */
    public void addVinyl(dk.via.pro3.generated.AddVinylRequest request,
        io.grpc.stub.StreamObserver<dk.via.pro3.generated.VinylResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddVinylMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getVinyl(dk.via.pro3.generated.GetVinylRequest request,
        io.grpc.stub.StreamObserver<dk.via.pro3.generated.VinylResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetVinylMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service VinylService.
   */
  public static final class VinylServiceBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<VinylServiceBlockingV2Stub> {
    private VinylServiceBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected VinylServiceBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new VinylServiceBlockingV2Stub(channel, callOptions);
    }

    /**
     */
    public dk.via.pro3.generated.VinylResponse addVinyl(dk.via.pro3.generated.AddVinylRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getAddVinylMethod(), getCallOptions(), request);
    }

    /**
     */
    public dk.via.pro3.generated.VinylResponse getVinyl(dk.via.pro3.generated.GetVinylRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getGetVinylMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service VinylService.
   */
  public static final class VinylServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<VinylServiceBlockingStub> {
    private VinylServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected VinylServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new VinylServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public dk.via.pro3.generated.VinylResponse addVinyl(dk.via.pro3.generated.AddVinylRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddVinylMethod(), getCallOptions(), request);
    }

    /**
     */
    public dk.via.pro3.generated.VinylResponse getVinyl(dk.via.pro3.generated.GetVinylRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetVinylMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service VinylService.
   */
  public static final class VinylServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<VinylServiceFutureStub> {
    private VinylServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected VinylServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new VinylServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<dk.via.pro3.generated.VinylResponse> addVinyl(
        dk.via.pro3.generated.AddVinylRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddVinylMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<dk.via.pro3.generated.VinylResponse> getVinyl(
        dk.via.pro3.generated.GetVinylRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetVinylMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_ADD_VINYL = 0;
  private static final int METHODID_GET_VINYL = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_ADD_VINYL:
          serviceImpl.addVinyl((dk.via.pro3.generated.AddVinylRequest) request,
              (io.grpc.stub.StreamObserver<dk.via.pro3.generated.VinylResponse>) responseObserver);
          break;
        case METHODID_GET_VINYL:
          serviceImpl.getVinyl((dk.via.pro3.generated.GetVinylRequest) request,
              (io.grpc.stub.StreamObserver<dk.via.pro3.generated.VinylResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getAddVinylMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              dk.via.pro3.generated.AddVinylRequest,
              dk.via.pro3.generated.VinylResponse>(
                service, METHODID_ADD_VINYL)))
        .addMethod(
          getGetVinylMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              dk.via.pro3.generated.GetVinylRequest,
              dk.via.pro3.generated.VinylResponse>(
                service, METHODID_GET_VINYL)))
        .build();
  }

  private static abstract class VinylServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    VinylServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return dk.via.pro3.generated.VinylOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("VinylService");
    }
  }

  private static final class VinylServiceFileDescriptorSupplier
      extends VinylServiceBaseDescriptorSupplier {
    VinylServiceFileDescriptorSupplier() {}
  }

  private static final class VinylServiceMethodDescriptorSupplier
      extends VinylServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    VinylServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (VinylServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new VinylServiceFileDescriptorSupplier())
              .addMethod(getAddVinylMethod())
              .addMethod(getGetVinylMethod())
              .build();
        }
      }
    }
    return result;
  }
}
