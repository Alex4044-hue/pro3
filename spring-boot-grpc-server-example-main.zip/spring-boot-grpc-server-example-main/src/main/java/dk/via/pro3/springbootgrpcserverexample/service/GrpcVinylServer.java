package dk.via.pro3.springbootgrpcserverexample.service;

import dk.via.pro3.generated.AddVinylRequest;
import dk.via.pro3.generated.GetVinylRequest;
import dk.via.pro3.generated.VinylResponse;
import dk.via.pro3.generated.VinylServiceGrpc;
import io.grpc.stub.StreamObserver;
import org.springframework.grpc.server.service.GrpcService;

@GrpcService
public class GrpcVinylServer extends VinylServiceGrpc.VinylServiceImplBase
{
  @Override public void addVinyl(AddVinylRequest request, StreamObserver<VinylResponse> responseObserver)
  {
    super.addVinyl(request, responseObserver);
  }

  @Override
  public void getVinyl(GetVinylRequest request, StreamObserver<VinylResponse> responseObserver)
  {
    super.getVinyl(request, responseObserver);
  }
}
